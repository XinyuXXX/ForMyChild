import pygame
import math
from typing import Optional, Tuple, List, Dict
from ..config import COLORS, WINDOW_WIDTH, WINDOW_HEIGHT, FONTS
from ..core.game_manager import GameManager
from ..utils.font_utils import get_chinese_font
from ..utils.audio_utils import speak, stop_speaking
from ..utils.ui_utils import SpeakerButton


class GameButton:
    """游戏按钮"""
    def __init__(self, x: int, y: int, width: int, height: int, 
                 text: str, game_type: str, icon: str, color: Tuple[int, int, int]):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.game_type = game_type
        self.icon = icon
        self.color = color
        self.hover = False
        self.scale = 1.0
        self.target_scale = 1.0
        
    def update(self, mouse_pos: Tuple[int, int]):
        """更新按钮状态"""
        self.hover = self.rect.collidepoint(mouse_pos)
        self.target_scale = 1.05 if self.hover else 1.0
        
        # 平滑缩放动画
        self.scale += (self.target_scale - self.scale) * 0.2
        
    def draw(self, screen: pygame.Surface):
        """绘制按钮"""
        # 计算缩放后的矩形
        scaled_width = int(self.rect.width * self.scale)
        scaled_height = int(self.rect.height * self.scale)
        scaled_rect = pygame.Rect(
            self.rect.centerx - scaled_width // 2,
            self.rect.centery - scaled_height // 2,
            scaled_width,
            scaled_height
        )
        
        # 绘制阴影
        shadow_rect = scaled_rect.copy()
        shadow_rect.x += 3
        shadow_rect.y += 3
        pygame.draw.rect(screen, (200, 200, 200), shadow_rect, border_radius=15)
        
        # 绘制按钮主体
        pygame.draw.rect(screen, self.color, scaled_rect, border_radius=15)
        
        # 绘制图标
        self._draw_icon(screen, scaled_rect)
        
        # 绘制文字
        font = get_chinese_font(24)
        text_surf = font.render(self.text, True, COLORS['white'])
        text_rect = text_surf.get_rect(center=(scaled_rect.centerx, scaled_rect.bottom - 20))
        screen.blit(text_surf, text_rect)
        
    def _draw_icon(self, screen: pygame.Surface, rect: pygame.Rect):
        """绘制图标"""
        icon_center_x = rect.centerx
        icon_center_y = rect.centery - 15
        
        if self.icon == 'find_difference':
            # 放大镜图标
            pygame.draw.circle(screen, COLORS['white'], (icon_center_x, icon_center_y), 20, 3)
            pygame.draw.line(screen, COLORS['white'], 
                           (icon_center_x + 14, icon_center_y + 14),
                           (icon_center_x + 24, icon_center_y + 24), 3)
        elif self.icon == 'counting':
            # 数字图标
            font = pygame.font.Font(None, 40)
            text = "123"
            text_surf = font.render(text, True, COLORS['white'])
            text_rect = text_surf.get_rect(center=(icon_center_x, icon_center_y))
            screen.blit(text_surf, text_rect)
        elif self.icon == 'math':
            # 加号图标
            size = 30
            pygame.draw.line(screen, COLORS['white'],
                           (icon_center_x - size//2, icon_center_y),
                           (icon_center_x + size//2, icon_center_y), 4)
            pygame.draw.line(screen, COLORS['white'],
                           (icon_center_x, icon_center_y - size//2),
                           (icon_center_x, icon_center_y + size//2), 4)
        elif self.icon == 'staff':
            # 五线谱图标
            for i in range(5):
                y = icon_center_y - 10 + i * 5
                pygame.draw.line(screen, COLORS['white'],
                               (icon_center_x - 20, y),
                               (icon_center_x + 20, y), 1)
            # 音符
            pygame.draw.ellipse(screen, COLORS['white'], 
                              pygame.Rect(icon_center_x - 5, icon_center_y - 8, 10, 8))
        elif self.icon == 'rhythm':
            # 节奏图标 - 四分音符
            pygame.draw.ellipse(screen, COLORS['white'], 
                              pygame.Rect(icon_center_x - 8, icon_center_y - 5, 16, 10))
            pygame.draw.line(screen, COLORS['white'],
                           (icon_center_x + 8, icon_center_y),
                           (icon_center_x + 8, icon_center_y - 20), 2)
        elif self.icon == 'interval':
            # 音程图标 - 两个音符
            pygame.draw.ellipse(screen, COLORS['white'], 
                              pygame.Rect(icon_center_x - 15, icon_center_y - 5, 10, 8))
            pygame.draw.ellipse(screen, COLORS['white'], 
                              pygame.Rect(icon_center_x + 5, icon_center_y - 10, 10, 8))
            pygame.draw.line(screen, COLORS['white'],
                           (icon_center_x - 5, icon_center_y),
                           (icon_center_x - 5, icon_center_y - 20), 2)
            pygame.draw.line(screen, COLORS['white'],
                           (icon_center_x + 15, icon_center_y - 5),
                           (icon_center_x + 15, icon_center_y - 25), 2)


class CategoryGroup:
    """游戏类别组"""
    def __init__(self, name: str, y: int, games: List[Dict]):
        self.name = name
        self.y = y
        self.games = games
        self.buttons = []
        
        # 创建游戏按钮
        button_width = 140
        button_height = 120
        spacing = 20
        
        # 计算起始x位置使按钮组居中
        total_width = len(games) * button_width + (len(games) - 1) * spacing
        start_x = (WINDOW_WIDTH - total_width) // 2
        
        for i, game in enumerate(games):
            x = start_x + i * (button_width + spacing)
            button = GameButton(
                x, y + 40, button_width, button_height,
                game['name'], game['type'], game['icon'], game['color']
            )
            self.buttons.append(button)
            
    def update(self, mouse_pos: Tuple[int, int]):
        """更新按钮状态"""
        for button in self.buttons:
            button.update(mouse_pos)
            
    def draw(self, screen: pygame.Surface, speaker_buttons: List):
        """绘制类别组"""
        # 绘制类别标题
        title_font = get_chinese_font(32)
        title_surf = title_font.render(self.name, True, COLORS['text'])
        title_rect = title_surf.get_rect(center=(WINDOW_WIDTH//2, self.y))
        screen.blit(title_surf, title_rect)
        
        # 添加喇叭按钮
        speaker_btn = SpeakerButton(WINDOW_WIDTH//2 + title_surf.get_width()//2 + 40, self.y, 20)
        speaker_btn.draw(screen)
        speaker_buttons.append((speaker_btn, f"这是{self.name}类游戏"))
        
        # 绘制游戏按钮
        for button in self.buttons:
            button.draw(screen)
            
    def handle_click(self, pos: Tuple[int, int]) -> Optional[str]:
        """处理点击事件"""
        for button in self.buttons:
            if button.rect.collidepoint(pos):
                return button.game_type
        return None


class GroupedMainMenu:
    """分组主菜单"""
    def __init__(self, game_manager: GameManager):
        self.game_manager = game_manager
        self.animation_time = 0
        
        # 定义游戏分组
        self.categories = [
            CategoryGroup("数理逻辑", 220, [
                {'name': '数一数', 'type': 'counting', 'icon': 'counting', 'color': COLORS['primary']},
                {'name': '算一算', 'type': 'simple_math', 'icon': 'math', 'color': COLORS['secondary']},
            ]),
            CategoryGroup("乐理", 380, [
                {'name': '五线谱', 'type': 'staff_reading', 'icon': 'staff', 'color': COLORS['accent']},
                {'name': '节奏', 'type': 'rhythm', 'icon': 'rhythm', 'color': COLORS['success']},
                {'name': '音程', 'type': 'interval', 'icon': 'interval', 'color': COLORS['warning']},
            ]),
            CategoryGroup("视觉加工", 540, [
                {'name': '找不同', 'type': 'find_difference', 'icon': 'find_difference', 'color': COLORS['danger']},
            ]),
        ]
        
        # 空的类别（准备未来扩展）
        self.future_categories = ["语言表达", "绘画"]
        
        # 退出按钮 - 放在右下角
        self.quit_button = pygame.Rect(WINDOW_WIDTH - 120, WINDOW_HEIGHT - 60, 100, 40)
        self.quit_hover = False
        
        # 设置按钮 - 放在左下角
        self.settings_button = pygame.Rect(20, WINDOW_HEIGHT - 60, 100, 40)
        self.settings_hover = False
        
        # 喇叭按钮
        self.speaker_buttons = []
        
        # 播放欢迎语音
        name = self.game_manager.progress.get_player_name()
        speak(f"欢迎{name}小朋友！请选择一个类别，然后选择游戏开始吧！")
        
    def handle_click(self, pos: Tuple[int, int]) -> Optional[str]:
        """处理点击事件，返回选中的游戏类型"""
        # 检查喇叭按钮点击
        for button, text in self.speaker_buttons:
            if button.check_click(pos):
                speak(text)
                return None
        
        # 检查退出按钮
        if self.quit_button.collidepoint(pos):
            return 'quit'
        
        # 检查设置按钮
        if self.settings_button.collidepoint(pos):
            speak("进入设置界面")
            return 'settings'
            
        # 检查游戏按钮
        for category in self.categories:
            game_type = category.handle_click(pos)
            if game_type:
                # 播放相应的语音提示
                voice_map = {
                    'find_difference': "让我们一起来找不同吧！",
                    'counting': "让我们一起来数数吧！",
                    'simple_math': "让我们一起来做数学题吧！",
                    'staff_reading': "让我们一起来认识五线谱吧！",
                    'rhythm': "让我们一起来学习节奏吧！",
                    'interval': "让我们一起来学习音程吧！"
                }
                speak(voice_map.get(game_type, "开始游戏！"))
                return game_type
                
        return None
        
    def update(self, dt: float, mouse_pos: Tuple[int, int]):
        """更新菜单状态"""
        self.animation_time += dt
        
        # 更新所有类别的按钮
        for category in self.categories:
            category.update(mouse_pos)
            
        # 更新退出按钮悬停状态
        self.quit_hover = self.quit_button.collidepoint(mouse_pos)
        
        # 更新设置按钮悬停状态
        self.settings_hover = self.settings_button.collidepoint(mouse_pos)
        
        # 更新喇叭按钮状态
        for button, _ in self.speaker_buttons:
            button.update(mouse_pos)
            
    def draw(self, screen: pygame.Surface):
        """绘制菜单"""
        # 绘制背景
        screen.fill(COLORS['background'])
        
        # 清空喇叭按钮列表
        self.speaker_buttons.clear()
        
        # 绘制装饰性背景元素
        self._draw_background_decorations(screen)
        
        # 绘制标题
        title_font = get_chinese_font(64)
        title = "聪明小宝贝"
        title_surf = title_font.render(title, True, COLORS['text'])
        title_rect = title_surf.get_rect(center=(WINDOW_WIDTH//2, 80))
        screen.blit(title_surf, title_rect)
        
        # 在标题旁边添加喇叭按钮
        speaker_btn = SpeakerButton(WINDOW_WIDTH//2 + title_surf.get_width()//2 + 60, 80, 30)
        speaker_btn.draw(screen)
        name = self.game_manager.progress.get_player_name()
        self.speaker_buttons.append((speaker_btn, f"欢迎{name}小朋友！请选择一个类别，然后选择游戏开始吧！"))
        
        # 绘制副标题
        subtitle_font = get_chinese_font(28)
        subtitle = "选择感兴趣的类别开始学习吧！"
        subtitle_surf = subtitle_font.render(subtitle, True, COLORS['text'])
        subtitle_rect = subtitle_surf.get_rect(center=(WINDOW_WIDTH//2, 130))
        screen.blit(subtitle_surf, subtitle_rect)
        
        # 绘制游戏类别
        for category in self.categories:
            category.draw(screen, self.speaker_buttons)
            
        # 绘制未来类别（灰色显示）
        future_y = 700
        future_font = get_chinese_font(28)
        future_text = "更多类别即将推出: " + " | ".join(self.future_categories)
        future_surf = future_font.render(future_text, True, (150, 150, 150))
        future_rect = future_surf.get_rect(center=(WINDOW_WIDTH//2, future_y))
        screen.blit(future_surf, future_rect)
        
        # 绘制玩家信息
        self._draw_player_info(screen)
        
        # 绘制退出按钮
        button_color = COLORS['danger'] if self.quit_hover else COLORS['secondary']
        pygame.draw.rect(screen, button_color, self.quit_button, border_radius=5)
        quit_font = get_chinese_font(24)
        quit_text = quit_font.render("退出游戏", True, COLORS['white'])
        quit_rect = quit_text.get_rect(center=self.quit_button.center)
        screen.blit(quit_text, quit_rect)
        
        # 绘制设置按钮
        settings_color = COLORS['primary'] if self.settings_hover else COLORS['secondary']
        pygame.draw.rect(screen, settings_color, self.settings_button, border_radius=5)
        settings_font = get_chinese_font(24)
        settings_text = settings_font.render("设置", True, COLORS['white'])
        settings_rect = settings_text.get_rect(center=self.settings_button.center)
        screen.blit(settings_text, settings_rect)
        
        # 绘制所有喇叭按钮
        for button, _ in self.speaker_buttons:
            button.draw(screen)
        
        # 退出提示
        hint_font = get_chinese_font(20)
        hint_text = hint_font.render("按 ESC 或 Ctrl+Q 也可退出", True, COLORS['text'])
        hint_rect = hint_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT - 20))
        screen.blit(hint_text, hint_rect)
        
    def _draw_background_decorations(self, screen: pygame.Surface):
        """绘制背景装饰"""
        # 绘制漂浮的图形
        shapes = [
            {'x': 100, 'y': 200, 'size': 30, 'color': (255, 200, 200), 'speed': 0.5},
            {'x': 900, 'y': 300, 'size': 25, 'color': (200, 255, 200), 'speed': 0.7},
            {'x': 200, 'y': 500, 'size': 35, 'color': (200, 200, 255), 'speed': 0.6},
            {'x': 800, 'y': 100, 'size': 20, 'color': (255, 255, 200), 'speed': 0.8},
            {'x': 150, 'y': 600, 'size': 28, 'color': (255, 220, 200), 'speed': 0.6},
            {'x': 850, 'y': 450, 'size': 22, 'color': (220, 255, 220), 'speed': 0.5},
        ]
        
        for shape in shapes:
            y_offset = math.sin(self.animation_time * shape['speed']) * 20
            pygame.draw.circle(screen, shape['color'], 
                             (shape['x'], int(shape['y'] + y_offset)), 
                             shape['size'])
            
    def _draw_player_info(self, screen: pygame.Surface):
        """绘制玩家信息"""
        info_font = get_chinese_font(28)
        
        # 玩家名字
        name = self.game_manager.progress.get_player_name()
        name_text = f"小朋友：{name}"
        name_surf = info_font.render(name_text, True, COLORS['text'])
        screen.blit(name_surf, (20, 20))
        
        # 显示月龄（如果有生日信息）
        birth_date = self.game_manager.progress.data.get('birth_date', None)
        if birth_date:
            try:
                import datetime
                year, month, day = birth_date.split('-')
                birth = datetime.date(int(year), int(month), int(day))
                today = datetime.date.today()
                months = (today.year - birth.year) * 12 + today.month - birth.month
                
                age_text = f"月龄：{months}个月"
                age_surf = info_font.render(age_text, True, COLORS['secondary'])
                screen.blit(age_surf, (20, 55))
            except:
                pass
        
        # 金币和星星 - 显示在右上角，使用图标和数字
        coins = self.game_manager.progress.data['total_coins']
        stars = self.game_manager.progress.data['total_stars']
        
        # 金币图标和数字
        coin_x = WINDOW_WIDTH - 200
        pygame.draw.circle(screen, COLORS['primary'], (coin_x, 35), 12)
        pygame.draw.circle(screen, (255, 215, 0), (coin_x, 35), 10)
        coins_text = f"{coins}"
        coins_surf = info_font.render(coins_text, True, COLORS['text'])
        screen.blit(coins_surf, (coin_x + 20, 23))
        
        # 星星图标和数字
        star_x = WINDOW_WIDTH - 100
        self._draw_small_star(screen, star_x, 35, 12, COLORS['accent'])
        stars_text = f"{stars}"
        stars_surf = info_font.render(stars_text, True, COLORS['text'])
        screen.blit(stars_surf, (star_x + 20, 23))
    
    def _draw_small_star(self, screen: pygame.Surface, x: int, y: int, size: int, color: Tuple[int, int, int]):
        """绘制小星星图标"""
        import math
        points = []
        for i in range(10):
            angle = math.pi * i / 5 - math.pi / 2
            if i % 2 == 0:
                radius = size
            else:
                radius = size * 0.5
            point_x = x + radius * math.cos(angle)
            point_y = y + radius * math.sin(angle)
            points.append((point_x, point_y))
        pygame.draw.polygon(screen, color, points)