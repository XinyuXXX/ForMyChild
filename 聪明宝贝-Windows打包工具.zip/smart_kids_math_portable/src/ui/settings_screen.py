#!/usr/bin/env python3
"""
设置界面 - 编辑玩家信息
"""
import pygame
import datetime
from typing import Optional, Tuple
from ..config import COLORS, WINDOW_WIDTH, WINDOW_HEIGHT
from ..utils.font_utils import get_chinese_font
from ..utils.audio_utils import speak
from ..utils.ui_utils import SpeakerButton
from ..utils.emoji_utils import draw_happy_face


class SettingsScreen:
    """设置界面"""
    
    def __init__(self, game_manager):
        self.game_manager = game_manager
        self.done = False
        
        # 获取当前信息
        self.player_name = game_manager.progress.get_player_name()
        self.birth_date = game_manager.progress.data.get('birth_date', None)
        
        # 输入状态
        self.editing_name = False
        self.editing_birth = False
        self.temp_name = self.player_name
        self.temp_birth_year = ""
        self.temp_birth_month = ""
        self.temp_birth_day = ""
        
        # 如果有生日信息，解析它
        if self.birth_date:
            try:
                year, month, day = self.birth_date.split('-')
                self.temp_birth_year = year
                self.temp_birth_month = month
                self.temp_birth_day = day
            except:
                pass
        
        # 输入框
        self.name_box = pygame.Rect(WINDOW_WIDTH//2 - 200, 200, 400, 50)
        self.year_box = pygame.Rect(WINDOW_WIDTH//2 - 200, 320, 120, 50)
        self.month_box = pygame.Rect(WINDOW_WIDTH//2 - 40, 320, 80, 50)
        self.day_box = pygame.Rect(WINDOW_WIDTH//2 + 80, 320, 80, 50)
        
        # 按钮
        self.save_button = pygame.Rect(WINDOW_WIDTH//2 - 150, 450, 130, 50)
        self.cancel_button = pygame.Rect(WINDOW_WIDTH//2 + 20, 450, 130, 50)
        
        # 光标
        self.cursor_visible = True
        self.cursor_timer = 0
        
        # 喇叭按钮
        self.speaker_buttons = []
        
        # 播放欢迎语音
        speak("这里可以修改你的名字和生日哦！")
        
    def handle_event(self, event: pygame.event.Event) -> Optional[str]:
        """处理事件，返回'save'、'cancel'或None"""
        if event.type == pygame.MOUSEBUTTONDOWN:
            # 检查喇叭按钮
            for button, text in self.speaker_buttons:
                if button.check_click(event.pos):
                    speak(text)
                    return None
            
            # 检查输入框点击
            self.editing_name = self.name_box.collidepoint(event.pos)
            self.editing_birth = False
            
            if self.year_box.collidepoint(event.pos):
                self.editing_birth = 'year'
            elif self.month_box.collidepoint(event.pos):
                self.editing_birth = 'month'
            elif self.day_box.collidepoint(event.pos):
                self.editing_birth = 'day'
            
            # 检查按钮
            if self.save_button.collidepoint(event.pos):
                if self._validate_and_save():
                    return 'save'
            elif self.cancel_button.collidepoint(event.pos):
                return 'cancel'
                
        elif event.type == pygame.KEYDOWN:
            if self.editing_name:
                if event.key == pygame.K_BACKSPACE:
                    self.temp_name = self.temp_name[:-1]
                elif event.key == pygame.K_RETURN:
                    self.editing_name = False
                elif len(self.temp_name) < 8 and event.unicode and event.unicode.isprintable():
                    self.temp_name += event.unicode
                    
            elif self.editing_birth:
                if event.key == pygame.K_BACKSPACE:
                    if self.editing_birth == 'year':
                        self.temp_birth_year = self.temp_birth_year[:-1]
                    elif self.editing_birth == 'month':
                        self.temp_birth_month = self.temp_birth_month[:-1]
                    elif self.editing_birth == 'day':
                        self.temp_birth_day = self.temp_birth_day[:-1]
                elif event.key == pygame.K_TAB:
                    # Tab键切换输入框
                    if self.editing_birth == 'year':
                        self.editing_birth = 'month'
                    elif self.editing_birth == 'month':
                        self.editing_birth = 'day'
                    else:
                        self.editing_birth = False
                elif event.unicode and event.unicode.isdigit():
                    if self.editing_birth == 'year' and len(self.temp_birth_year) < 4:
                        self.temp_birth_year += event.unicode
                    elif self.editing_birth == 'month' and len(self.temp_birth_month) < 2:
                        self.temp_birth_month += event.unicode
                    elif self.editing_birth == 'day' and len(self.temp_birth_day) < 2:
                        self.temp_birth_day += event.unicode
                        
        return None
    
    def update(self, dt: float):
        """更新界面状态"""
        # 更新光标闪烁
        self.cursor_timer += dt
        if self.cursor_timer >= 0.5:
            self.cursor_visible = not self.cursor_visible
            self.cursor_timer = 0
            
        # 更新喇叭按钮
        mouse_pos = pygame.mouse.get_pos()
        for button, _ in self.speaker_buttons:
            button.update(mouse_pos)
    
    def draw(self, screen: pygame.Surface):
        """绘制界面"""
        screen.fill(COLORS['background'])
        
        # 清空喇叭按钮列表
        self.speaker_buttons.clear()
        
        # 标题
        title_font = get_chinese_font(48)
        title = "个人信息设置"
        title_surf = title_font.render(title, True, COLORS['text'])
        title_rect = title_surf.get_rect(center=(WINDOW_WIDTH//2, 80))
        screen.blit(title_surf, title_rect)
        
        # 名字部分
        label_font = get_chinese_font(32)
        name_label = label_font.render("小朋友的名字：", True, COLORS['text'])
        screen.blit(name_label, (self.name_box.x - 150, self.name_box.y + 10))
        
        # 名字输入框
        box_color = COLORS['primary'] if self.editing_name else COLORS['secondary']
        pygame.draw.rect(screen, COLORS['white'], self.name_box)
        pygame.draw.rect(screen, box_color, self.name_box, 3, border_radius=5)
        
        if self.temp_name:
            name_font = get_chinese_font(36)
            name_surf = name_font.render(self.temp_name, True, COLORS['text'])
            name_rect = name_surf.get_rect(center=self.name_box.center)
            screen.blit(name_surf, name_rect)
            
            if self.editing_name and self.cursor_visible:
                cursor_x = name_rect.right + 5
                pygame.draw.line(screen, COLORS['text'], 
                               (cursor_x, self.name_box.y + 10),
                               (cursor_x, self.name_box.y + 40), 2)
        
        # 生日部分
        birth_label = label_font.render("出生日期：", True, COLORS['text'])
        screen.blit(birth_label, (self.year_box.x - 150, self.year_box.y + 10))
        
        # 年份输入框
        year_color = COLORS['primary'] if self.editing_birth == 'year' else COLORS['secondary']
        pygame.draw.rect(screen, COLORS['white'], self.year_box)
        pygame.draw.rect(screen, year_color, self.year_box, 3, border_radius=5)
        
        year_text = self.temp_birth_year if self.temp_birth_year else "年份"
        year_color_text = COLORS['text'] if self.temp_birth_year else COLORS['light_gray']
        year_surf = label_font.render(year_text, True, year_color_text)
        year_rect = year_surf.get_rect(center=self.year_box.center)
        screen.blit(year_surf, year_rect)
        
        # 月份输入框
        month_color = COLORS['primary'] if self.editing_birth == 'month' else COLORS['secondary']
        pygame.draw.rect(screen, COLORS['white'], self.month_box)
        pygame.draw.rect(screen, month_color, self.month_box, 3, border_radius=5)
        
        month_text = self.temp_birth_month if self.temp_birth_month else "月"
        month_color_text = COLORS['text'] if self.temp_birth_month else COLORS['light_gray']
        month_surf = label_font.render(month_text, True, month_color_text)
        month_rect = month_surf.get_rect(center=self.month_box.center)
        screen.blit(month_surf, month_rect)
        
        # 日期输入框
        day_color = COLORS['primary'] if self.editing_birth == 'day' else COLORS['secondary']
        pygame.draw.rect(screen, COLORS['white'], self.day_box)
        pygame.draw.rect(screen, day_color, self.day_box, 3, border_radius=5)
        
        day_text = self.temp_birth_day if self.temp_birth_day else "日"
        day_color_text = COLORS['text'] if self.temp_birth_day else COLORS['light_gray']
        day_surf = label_font.render(day_text, True, day_color_text)
        day_rect = day_surf.get_rect(center=self.day_box.center)
        screen.blit(day_surf, day_rect)
        
        # 显示月龄
        if self.temp_birth_year and self.temp_birth_month and self.temp_birth_day:
            try:
                birth = datetime.date(int(self.temp_birth_year), 
                                    int(self.temp_birth_month), 
                                    int(self.temp_birth_day))
                today = datetime.date.today()
                months = (today.year - birth.year) * 12 + today.month - birth.month
                
                if months >= 0:
                    age_text = f"当前月龄：{months}个月"
                    age_surf = label_font.render(age_text, True, COLORS['success'])
                    age_rect = age_surf.get_rect(center=(WINDOW_WIDTH//2, 390))
                    screen.blit(age_surf, age_rect)
                    
                    # 在月龄旁边添加喇叭按钮
                    speaker_btn = SpeakerButton(WINDOW_WIDTH//2 + 120, 390, 20)
                    speaker_btn.draw(screen)
                    self.speaker_buttons.append((speaker_btn, age_text))
            except:
                pass
        
        # 按钮
        # 保存按钮
        pygame.draw.rect(screen, COLORS['success'], self.save_button, border_radius=25)
        save_text = label_font.render("保存", True, COLORS['white'])
        save_rect = save_text.get_rect(center=self.save_button.center)
        screen.blit(save_text, save_rect)
        
        # 取消按钮
        pygame.draw.rect(screen, COLORS['secondary'], self.cancel_button, border_radius=25)
        cancel_text = label_font.render("取消", True, COLORS['white'])
        cancel_rect = cancel_text.get_rect(center=self.cancel_button.center)
        screen.blit(cancel_text, cancel_rect)
        
        # 装饰
        draw_happy_face(screen, 100, 100, 60, color=(255, 182, 193))
        draw_happy_face(screen, WINDOW_WIDTH - 100, 100, 60, color=(135, 206, 235))
        
        # 绘制所有喇叭按钮
        for button, _ in self.speaker_buttons:
            button.draw(screen)
    
    def _validate_and_save(self) -> bool:
        """验证并保存数据"""
        if not self.temp_name:
            speak("请输入小朋友的名字")
            return False
        
        # 保存名字
        self.game_manager.progress.data['player_name'] = self.temp_name
        
        # 验证并保存生日
        if self.temp_birth_year and self.temp_birth_month and self.temp_birth_day:
            try:
                year = int(self.temp_birth_year)
                month = int(self.temp_birth_month)
                day = int(self.temp_birth_day)
                
                # 验证日期合法性
                birth_date = datetime.date(year, month, day)
                today = datetime.date.today()
                
                if birth_date > today:
                    speak("生日不能是未来的日期哦")
                    return False
                
                # 计算月龄
                months = (today.year - birth_date.year) * 12 + today.month - birth_date.month
                if months < 36:  # 小于3岁
                    speak("这个游戏适合3岁以上的小朋友哦")
                    return False
                elif months > 120:  # 大于10岁
                    speak("这个游戏是为3到10岁的小朋友设计的")
                    return False
                
                # 保存生日
                self.game_manager.progress.data['birth_date'] = f"{year}-{month:02d}-{day:02d}"
                
            except ValueError:
                speak("请输入正确的日期")
                return False
        
        # 保存进度
        self.game_manager.progress.save_progress()
        speak(f"已保存{self.temp_name}的信息")
        return True
    
    def get_result(self) -> dict:
        """获取设置结果"""
        return {
            'name': self.temp_name,
            'birth_date': f"{self.temp_birth_year}-{self.temp_birth_month}-{self.temp_birth_day}" 
                        if all([self.temp_birth_year, self.temp_birth_month, self.temp_birth_day]) 
                        else None
        }