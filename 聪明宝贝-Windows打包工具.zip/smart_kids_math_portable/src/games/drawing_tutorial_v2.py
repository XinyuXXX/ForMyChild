#!/usr/bin/env python3
"""
改进版画画教学游戏 - 使用图片素材
帮助4岁儿童提高观察力和绘画能力
"""
import pygame
import os
from typing import List, Dict, Tuple, Optional
from ..config import COLORS, WINDOW_WIDTH, WINDOW_HEIGHT, IMAGES_PATH
from ..utils.font_utils import get_chinese_font
from ..utils.audio_utils import speak
from ..utils.ui_utils import SpeakerButton
from ..utils.emoji_utils import draw_happy_face, draw_star_eyes_face
from .base_game import BaseGame


class ImageBasedStep:
    """基于图片的绘画步骤"""
    def __init__(self, description: str, layer_image: pygame.Surface, 
                 mask_start: float = 0.0, mask_end: float = 1.0):
        self.description = description
        self.layer_image = layer_image
        self.mask_start = mask_start  # 开始显示的进度 (0-1)
        self.mask_end = mask_end      # 结束显示的进度 (0-1)
        

class ImageBasedTutorial:
    """基于图片的绘画教程"""
    def __init__(self, name: str, category: str, difficulty: int):
        self.name = name
        self.category = category
        self.difficulty = difficulty
        
        # 图片资源
        self.real_image: Optional[pygame.Surface] = None
        self.simple_drawing: Optional[pygame.Surface] = None
        self.drawing_layers: List[pygame.Surface] = []  # 分层的简笔画
        self.steps: List[ImageBasedStep] = []
        
        # 颜色信息
        self.colors: List[Tuple[int, int, int]] = []
        
    def load_real_image(self, filename: str) -> bool:
        """加载真实物品照片"""
        path = os.path.join(IMAGES_PATH, "drawing_tutorials", filename)
        if os.path.exists(path):
            try:
                self.real_image = pygame.image.load(path)
                return True
            except:
                print(f"加载真实图片失败: {path}")
        return False
        
    def load_simple_drawing(self, filename: str) -> bool:
        """加载完整的简笔画"""
        path = os.path.join(IMAGES_PATH, "drawing_tutorials", filename)
        if os.path.exists(path):
            try:
                self.simple_drawing = pygame.image.load(path)
                return True
            except:
                print(f"加载简笔画失败: {path}")
        return False
        
    def add_layer(self, filename: str, description: str, 
                  start_progress: float = 0.0, end_progress: float = 1.0) -> bool:
        """添加一个绘画层"""
        path = os.path.join(IMAGES_PATH, "drawing_tutorials", filename)
        if os.path.exists(path):
            try:
                layer = pygame.image.load(path)
                self.drawing_layers.append(layer)
                step = ImageBasedStep(description, layer, start_progress, end_progress)
                self.steps.append(step)
                return True
            except:
                print(f"加载图层失败: {path}")
        return False


class DrawingTutorialV2(BaseGame):
    """改进版画画教学游戏"""
    
    def __init__(self):
        super().__init__()
        self.game_type = "drawing"
        
        # 教程列表
        self.tutorials: List[ImageBasedTutorial] = []
        self.current_tutorial: Optional[ImageBasedTutorial] = None
        self.current_step = 0
        
        # 游戏阶段
        self.game_phase = 'real_image'  # real_image, simple_drawing, steps, complete
        self.phase_timer = 0.0
        
        # 动画控制
        self.step_progress = 0.0
        self.is_paused = True
        self.auto_advance = False
        
        # UI元素
        self.continue_button = None
        self.pause_button = None
        self.prev_button = None
        self.next_button = None
        self.restart_button = None
        
        # 反馈
        self.show_complete_feedback = False
        
        # 喇叭按钮
        self.speaker_buttons = []
        
        # 初始化教程
        self._create_tutorials()
        self._select_tutorial()
        
    def _create_tutorials(self):
        """创建教程列表"""
        # 太阳教程
        sun_tutorial = ImageBasedTutorial("太阳", "自然", 1)
        if sun_tutorial.load_real_image("sun_real.jpg"):
            if sun_tutorial.load_simple_drawing("sun_simple.png"):
                # 添加分步图层
                sun_tutorial.add_layer("sun_step1.png", "先画一个圆圈", 0.0, 0.4)
                sun_tutorial.add_layer("sun_step2.png", "加上光芒", 0.4, 0.8)
                sun_tutorial.add_layer("sun_step3.png", "涂上黄色", 0.8, 1.0)
                sun_tutorial.colors = [(255, 223, 0), (255, 140, 0)]
                self.tutorials.append(sun_tutorial)
        
        # 房子教程
        house_tutorial = ImageBasedTutorial("房子", "物品", 2)
        if house_tutorial.load_real_image("house_real.jpg"):
            if house_tutorial.load_simple_drawing("house_simple.png"):
                house_tutorial.add_layer("house_step1.png", "先画一个正方形", 0.0, 0.3)
                house_tutorial.add_layer("house_step2.png", "加上三角形屋顶", 0.3, 0.6)
                house_tutorial.add_layer("house_step3.png", "画上门和窗户", 0.6, 0.9)
                house_tutorial.add_layer("house_step4.png", "涂上颜色", 0.9, 1.0)
                house_tutorial.colors = [(139, 69, 19), (255, 0, 0), (135, 206, 235)]
                self.tutorials.append(house_tutorial)
                
        # 如果没有图片资源，使用程序生成的简单示例
        if not self.tutorials:
            self._create_fallback_tutorials()
            
    def _create_fallback_tutorials(self):
        """创建备用教程（当没有图片资源时）"""
        # 创建一个提示教程
        tutorial = ImageBasedTutorial("示例", "示例", 1)
        self.tutorials.append(tutorial)
        
    def _select_tutorial(self):
        """选择教程"""
        if self.tutorials:
            # 根据难度选择
            suitable_tutorials = [t for t in self.tutorials 
                                if t.difficulty <= self.get_difficulty()]
            if suitable_tutorials:
                import random
                self.current_tutorial = random.choice(suitable_tutorials)
            else:
                self.current_tutorial = self.tutorials[0]
                
            self.current_step = 0
            self.step_progress = 0.0
            self.game_phase = 'real_image'
            self.show_complete_feedback = False
            
    def handle_click(self, pos: Tuple[int, int]):
        """处理点击事件"""
        # 检查喇叭按钮
        for button, text in self.speaker_buttons:
            if button.check_click(pos):
                speak(text)
                return
                
        if self.game_phase == 'real_image':
            # 查看简笔画
            self.game_phase = 'simple_drawing'
            speak("这是简笔画的样子，很简单吧！")
            
        elif self.game_phase == 'simple_drawing':
            # 开始分步教学
            self.game_phase = 'steps'
            self.current_step = 0
            self.step_progress = 0.0
            self.is_paused = True
            if self.current_tutorial and self.current_tutorial.steps:
                speak(f"让我们一步一步学习画{self.current_tutorial.name}。{self.current_tutorial.steps[0].description}")
                
        elif self.game_phase == 'steps':
            # 检查按钮点击
            if self.pause_button and self.pause_button.collidepoint(pos):
                self.is_paused = not self.is_paused
                speak("继续播放" if not self.is_paused else "已暂停，请跟着画")
                
            elif self.prev_button and self.prev_button.collidepoint(pos):
                if self.current_step > 0:
                    self.current_step -= 1
                    self.step_progress = 0.0
                    speak(self.current_tutorial.steps[self.current_step].description)
                    
            elif self.next_button and self.next_button.collidepoint(pos):
                if self.current_step < len(self.current_tutorial.steps) - 1:
                    self.current_step += 1
                    self.step_progress = 0.0
                    speak(self.current_tutorial.steps[self.current_step].description)
                else:
                    # 完成教程
                    self.game_phase = 'complete'
                    self.show_complete_feedback = True
                    speak(f"太棒了！你学会了画{self.current_tutorial.name}！")
                    
            elif self.restart_button and self.restart_button.collidepoint(pos):
                self.current_step = 0
                self.step_progress = 0.0
                speak("让我们重新开始")
                
        elif self.game_phase == 'complete':
            # 选择新教程
            self._select_tutorial()
            speak(f"让我们来学画{self.current_tutorial.name}")
            
    def update(self, dt: float):
        """更新游戏状态"""
        # 更新步骤进度
        if self.game_phase == 'steps' and not self.is_paused:
            self.step_progress = min(1.0, self.step_progress + dt / 3.0)  # 3秒完成一个步骤
            
            # 自动进入下一步
            if self.step_progress >= 1.0 and self.auto_advance:
                if self.current_step < len(self.current_tutorial.steps) - 1:
                    self.current_step += 1
                    self.step_progress = 0.0
                    speak(self.current_tutorial.steps[self.current_step].description)
                    
        # 更新喇叭按钮
        mouse_pos = pygame.mouse.get_pos()
        for button, _ in self.speaker_buttons:
            button.update(mouse_pos)
            
        # 创建UI按钮
        if self.game_phase == 'steps':
            self._create_ui_buttons()
            
    def _create_ui_buttons(self):
        """创建UI按钮"""
        button_y = self.window_height - self.scale_value(80)
        button_width = self.scale_value(100)
        button_height = self.scale_value(50)
        spacing = self.scale_value(20)
        
        # 计算按钮位置
        total_width = 4 * button_width + 3 * spacing
        start_x = (self.window_width - total_width) // 2
        
        # 暂停/继续按钮
        self.pause_button = pygame.Rect(start_x, button_y, button_width, button_height)
        
        # 上一步按钮
        self.prev_button = pygame.Rect(start_x + button_width + spacing, button_y, 
                                       button_width, button_height)
        
        # 下一步按钮
        self.next_button = pygame.Rect(start_x + 2 * (button_width + spacing), button_y, 
                                       button_width, button_height)
        
        # 重新开始按钮
        self.restart_button = pygame.Rect(start_x + 3 * (button_width + spacing), button_y, 
                                         button_width, button_height)
            
    def draw(self, screen: pygame.Surface):
        """绘制游戏画面"""
        screen.fill(COLORS['background'])
        
        # 清空喇叭按钮
        self.speaker_buttons.clear()
        
        # 绘制标题
        title_font = get_chinese_font(self.scale_font_size(48))
        title = f"学画画 - {self.current_tutorial.name if self.current_tutorial else '加载中'}"
        title_surf = title_font.render(title, True, COLORS['text'])
        title_rect = title_surf.get_rect(center=(self.get_center_x(), self.scale_value(50)))
        screen.blit(title_surf, title_rect)
        
        # 添加喇叭按钮
        speaker_btn = SpeakerButton(
            self.get_center_x() + title_surf.get_width()//2 + self.scale_value(50),
            self.scale_value(50),
            self.scale_value(25)
        )
        speaker_btn.draw(screen)
        self.speaker_buttons.append((speaker_btn, f"让我们来学画{self.current_tutorial.name if self.current_tutorial else '示例'}"))
        
        # 根据游戏阶段绘制内容
        center_x = self.get_center_x()
        center_y = self.get_center_y()
        
        if not self.current_tutorial:
            # 显示提示信息
            self._draw_no_resources_message(screen, center_x, center_y)
            return
            
        if self.game_phase == 'real_image':
            self._draw_real_image(screen, center_x, center_y)
            
        elif self.game_phase == 'simple_drawing':
            self._draw_simple_drawing(screen, center_x, center_y)
            
        elif self.game_phase == 'steps':
            self._draw_steps(screen, center_x, center_y)
            self._draw_ui_buttons(screen)
            
        elif self.game_phase == 'complete':
            self._draw_complete(screen, center_x, center_y)
            
        # 绘制所有喇叭按钮
        for button, _ in self.speaker_buttons:
            button.draw(screen)
            
    def _draw_no_resources_message(self, screen: pygame.Surface, x: int, y: int):
        """绘制没有资源的提示信息"""
        message_font = get_chinese_font(self.scale_font_size(32))
        
        messages = [
            "需要准备简笔画图片资源",
            "",
            "请在以下目录添加图片：",
            "assets/images/drawing_tutorials/",
            "",
            "需要的图片文件：",
            "- sun_real.jpg (真实太阳照片)",
            "- sun_simple.png (太阳简笔画)",
            "- sun_step1.png (第一步)",
            "- sun_step2.png (第二步)",
            "- sun_step3.png (第三步)"
        ]
        
        y_offset = -len(messages) * 20
        for msg in messages:
            color = COLORS['secondary'] if msg.startswith("-") or "assets" in msg else COLORS['text']
            msg_surf = message_font.render(msg, True, color)
            msg_rect = msg_surf.get_rect(center=(x, y + y_offset))
            screen.blit(msg_surf, msg_rect)
            y_offset += 40
            
    def _draw_real_image(self, screen: pygame.Surface, x: int, y: int):
        """绘制真实物品图片"""
        if self.current_tutorial.real_image:
            # 缩放图片以适应屏幕
            img = self.current_tutorial.real_image
            max_size = self.scale_value(400)
            
            # 计算缩放比例
            scale = min(max_size / img.get_width(), max_size / img.get_height())
            new_width = int(img.get_width() * scale)
            new_height = int(img.get_height() * scale)
            
            scaled_img = pygame.transform.scale(img, (new_width, new_height))
            img_rect = scaled_img.get_rect(center=(x, y))
            screen.blit(scaled_img, img_rect)
        else:
            # 显示占位符
            pygame.draw.rect(screen, COLORS['secondary'], 
                           (x - 200, y - 200, 400, 400), 3)
            font = get_chinese_font(self.scale_font_size(24))
            text = f"真实的{self.current_tutorial.name}"
            text_surf = font.render(text, True, COLORS['text'])
            text_rect = text_surf.get_rect(center=(x, y))
            screen.blit(text_surf, text_rect)
            
        # 提示文字
        hint_font = get_chinese_font(self.scale_font_size(24))
        hint_text = "点击查看简笔画"
        hint_surf = hint_font.render(hint_text, True, COLORS['secondary'])
        hint_rect = hint_surf.get_rect(center=(x, y + self.scale_value(250)))
        screen.blit(hint_surf, hint_rect)
        
    def _draw_simple_drawing(self, screen: pygame.Surface, x: int, y: int):
        """绘制完整的简笔画"""
        if self.current_tutorial.simple_drawing:
            # 缩放图片
            img = self.current_tutorial.simple_drawing
            max_size = self.scale_value(400)
            
            scale = min(max_size / img.get_width(), max_size / img.get_height())
            new_width = int(img.get_width() * scale)
            new_height = int(img.get_height() * scale)
            
            scaled_img = pygame.transform.scale(img, (new_width, new_height))
            img_rect = scaled_img.get_rect(center=(x, y))
            screen.blit(scaled_img, img_rect)
        else:
            # 显示占位符
            pygame.draw.rect(screen, COLORS['primary'], 
                           (x - 200, y - 200, 400, 400), 3)
            font = get_chinese_font(self.scale_font_size(24))
            text = f"{self.current_tutorial.name}的简笔画"
            text_surf = font.render(text, True, COLORS['text'])
            text_rect = text_surf.get_rect(center=(x, y))
            screen.blit(text_surf, text_rect)
            
        # 显示颜色提示
        self._draw_color_palette(screen)
        
        # 提示文字
        hint_font = get_chinese_font(self.scale_font_size(24))
        hint_text = "点击开始学习步骤"
        hint_surf = hint_font.render(hint_text, True, COLORS['secondary'])
        hint_rect = hint_surf.get_rect(center=(x, y + self.scale_value(250)))
        screen.blit(hint_surf, hint_rect)
        
    def _draw_steps(self, screen: pygame.Surface, x: int, y: int):
        """绘制分步教学"""
        if self.current_tutorial.drawing_layers:
            # 绘制所有已完成的图层
            max_size = self.scale_value(400)
            
            for i in range(self.current_step + 1):
                if i < len(self.current_tutorial.drawing_layers):
                    layer = self.current_tutorial.drawing_layers[i]
                    
                    # 计算缩放
                    scale = min(max_size / layer.get_width(), max_size / layer.get_height())
                    new_width = int(layer.get_width() * scale)
                    new_height = int(layer.get_height() * scale)
                    
                    scaled_layer = pygame.transform.scale(layer, (new_width, new_height))
                    
                    # 如果是当前步骤，根据进度显示
                    if i == self.current_step:
                        # 创建遮罩效果
                        alpha = int(255 * self.step_progress)
                        scaled_layer.set_alpha(alpha)
                        
                    layer_rect = scaled_layer.get_rect(center=(x, y))
                    screen.blit(scaled_layer, layer_rect)
        else:
            # 使用占位符
            step_text = self.current_tutorial.steps[self.current_step].description if self.current_tutorial.steps else "示例步骤"
            font = get_chinese_font(self.scale_font_size(32))
            text_surf = font.render(step_text, True, COLORS['primary'])
            text_rect = text_surf.get_rect(center=(x, y))
            screen.blit(text_surf, text_rect)
            
        # 显示当前步骤说明
        if self.current_step < len(self.current_tutorial.steps):
            step_font = get_chinese_font(self.scale_font_size(32))
            step_text = self.current_tutorial.steps[self.current_step].description
            step_surf = step_font.render(step_text, True, COLORS['primary'])
            step_rect = step_surf.get_rect(center=(x, self.scale_value(120)))
            screen.blit(step_surf, step_rect)
            
            # 步骤进度
            progress_text = f"步骤 {self.current_step + 1}/{len(self.current_tutorial.steps)}"
            progress_surf = step_font.render(progress_text, True, COLORS['text'])
            progress_rect = progress_surf.get_rect(topright=(self.window_width - self.scale_value(20), 
                                                             self.scale_value(20)))
            screen.blit(progress_surf, progress_rect)
            
    def _draw_complete(self, screen: pygame.Surface, x: int, y: int):
        """绘制完成画面"""
        # 显示完整的简笔画
        if self.current_tutorial.simple_drawing:
            img = self.current_tutorial.simple_drawing
            max_size = self.scale_value(400)
            
            scale = min(max_size / img.get_width(), max_size / img.get_height())
            new_width = int(img.get_width() * scale)
            new_height = int(img.get_height() * scale)
            
            scaled_img = pygame.transform.scale(img, (new_width, new_height))
            img_rect = scaled_img.get_rect(center=(x, y))
            screen.blit(scaled_img, img_rect)
            
        # 显示庆祝
        if self.show_complete_feedback:
            draw_star_eyes_face(screen, x, y - self.scale_value(250), 
                               self.scale_value(100))
            
            complete_font = get_chinese_font(self.scale_font_size(48))
            complete_text = "太棒了！"
            complete_surf = complete_font.render(complete_text, True, COLORS['success'])
            complete_rect = complete_surf.get_rect(center=(x, y + self.scale_value(200)))
            screen.blit(complete_surf, complete_rect)
            
            hint_font = get_chinese_font(self.scale_font_size(24))
            hint_text = "点击学习新的画画"
            hint_surf = hint_font.render(hint_text, True, COLORS['secondary'])
            hint_rect = hint_surf.get_rect(center=(x, y + self.scale_value(250)))
            screen.blit(hint_surf, hint_rect)
            
    def _draw_color_palette(self, screen: pygame.Surface):
        """绘制颜色调色板"""
        if not self.current_tutorial.colors:
            return
            
        palette_y = self.window_height - self.scale_value(150)
        color_size = self.scale_value(40)
        spacing = self.scale_value(10)
        
        # 计算起始位置
        total_width = len(self.current_tutorial.colors) * (color_size + spacing) - spacing
        start_x = (self.window_width - total_width) // 2
        
        # 绘制颜色提示
        label_font = get_chinese_font(self.scale_font_size(20))
        label_text = "使用的颜色："
        label_surf = label_font.render(label_text, True, COLORS['text'])
        label_rect = label_surf.get_rect(center=(self.get_center_x(), 
                                                palette_y - self.scale_value(30)))
        screen.blit(label_surf, label_rect)
        
        # 绘制颜色块
        for i, color in enumerate(self.current_tutorial.colors):
            x = start_x + i * (color_size + spacing)
            color_rect = pygame.Rect(x, palette_y, color_size, color_size)
            pygame.draw.rect(screen, color, color_rect)
            pygame.draw.rect(screen, COLORS['text'], color_rect, 2)
            
    def _draw_ui_buttons(self, screen: pygame.Surface):
        """绘制UI按钮"""
        button_font = get_chinese_font(self.scale_font_size(24))
        
        # 暂停/继续按钮
        if self.pause_button:
            pause_text = "继续" if self.is_paused else "暂停"
            pause_color = COLORS['success'] if self.is_paused else COLORS['secondary']
            pygame.draw.rect(screen, pause_color, self.pause_button, border_radius=5)
            pause_surf = button_font.render(pause_text, True, COLORS['white'])
            pause_rect = pause_surf.get_rect(center=self.pause_button.center)
            screen.blit(pause_surf, pause_rect)
            
        # 上一步按钮
        if self.prev_button:
            prev_color = COLORS['secondary'] if self.current_step > 0 else COLORS['disabled']
            pygame.draw.rect(screen, prev_color, self.prev_button, border_radius=5)
            prev_surf = button_font.render("上一步", True, COLORS['white'])
            prev_rect = prev_surf.get_rect(center=self.prev_button.center)
            screen.blit(prev_surf, prev_rect)
            
        # 下一步按钮
        if self.next_button:
            next_text = "完成" if self.current_step == len(self.current_tutorial.steps) - 1 else "下一步"
            pygame.draw.rect(screen, COLORS['primary'], self.next_button, border_radius=5)
            next_surf = button_font.render(next_text, True, COLORS['white'])
            next_rect = next_surf.get_rect(center=self.next_button.center)
            screen.blit(next_surf, next_rect)
            
        # 重新开始按钮
        if self.restart_button:
            pygame.draw.rect(screen, COLORS['warning'], self.restart_button, border_radius=5)
            restart_surf = button_font.render("重新开始", True, COLORS['white'])
            restart_rect = restart_surf.get_rect(center=self.restart_button.center)
            screen.blit(restart_surf, restart_rect)
            
    def get_result(self) -> Dict:
        """获取游戏结果"""
        # 画画游戏主要是学习，不计分
        return {
            'completed': True,
            'score': 100,
            'stars': 3,
            'coins': 10,
            'learned': self.current_tutorial.name if self.current_tutorial else "示例"
        }