# 字体文件说明

请在此目录下放置中文字体文件（.ttf格式）

推荐字体：
- 思源黑体 (SourceHanSansCN-Regular.ttf)
- 微软雅黑 (msyh.ttf)
- 文泉驿微米黑 (wqy-microhei.ttc)

可以从以下网站免费下载：
- 思源黑体：https://github.com/adobe-fonts/source-han-sans/releases
- 文泉驿：http://wenq.org/